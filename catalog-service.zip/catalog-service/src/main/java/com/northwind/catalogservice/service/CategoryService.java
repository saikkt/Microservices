package com.northwind.catalogservice.service;

import com.northwind.catalogservice.api.CategoryMapper;
import com.northwind.catalogservice.api.CategoryModel;
import com.northwind.catalogservice.domain.Category;
import com.northwind.catalogservice.domain.Product;
import com.northwind.catalogservice.repository.CategoryRepository;
import com.northwind.catalogservice.repository.ProductRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CategoryService {

    private CategoryRepository categoryRepository;
    private ProductRepository productRepository;

    public CategoryService(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    public List<Category> getAll(int page, int size){
        return categoryRepository.findAll(PageRequest.of(page,size)).toList();
    }

    public Category save(Category category){
        return categoryRepository.save(category);
    }

    public Optional<Category> getbyId(long categoryId){
        return categoryRepository.findById(categoryId);
    }
}
